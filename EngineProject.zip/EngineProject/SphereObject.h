//
// Created by Cedric Plouvier on 2019-09-27.
//

#ifndef ENGINEPROJECT_SPHEREOBJECT_H
#define ENGINEPROJECT_SPHEREOBJECT_H

#include "Object.h"
#include "Vector4.h"
#include <math.h>
#include <vector>
#include <cmath>


class SphereObject : public Object {
public:
    SphereObject(double xo, double yo, double zo, double r);
    virtual ~SphereObject();

    Vector4 getCenter();
    void setCenter(double x, double y, double z);

    list<HitPoint*> hit(RayObject* r) override;
    list<HitPoint*> objectOriginHit(RayObject* tr) override;
    void transformHitpoints();
    void setColorSphere(double r, double g, double b);
    Color getColorSphere();
    bool shadowFeeler(RayObject* shadowRay);

private:

    void shading();
    Color color;
    Vector4 center;
    double radius;
    list<HitPoint*> hits;
    RayObject rayz;
};


#endif //ENGINEPROJECT_SPHEREOBJECT_H
