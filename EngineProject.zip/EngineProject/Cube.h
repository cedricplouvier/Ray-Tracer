//
// Created by Cedric Plouvier on 2019-10-29.
//

#ifndef ENGINEPROJECT_CUBE_H
#define ENGINEPROJECT_CUBE_H

#include "Plane.h"
#include "Object.h"


class Cube: public Object {
public:
    virtual ~Cube();
    Cube(double size);

    list<HitPoint*> hit(RayObject* r) override;
    list<HitPoint*> objectOriginHit(RayObject* tr) override;
    void transformHitpoints();
    void changePlaneColor(Color c, int planeNumber);
    void setCubeColor(Color c);
    void setRibSize(double rs);
    double getRibSize();

private:
    void shading();
    double ribSize;
    list<HitPoint*> hits;
    list<Vector4*> cubePoints;
    list<Plane*> cubePlanes;
    RayObject rayz;
};


#endif //ENGINEPROJECT_CUBE_H
