//
// Created by Cedric Plouvier on 2019-10-29.
//

#include "Plane.h"

Plane::~Plane() {}

Plane::Plane() {

}

Plane::Plane(Vector4 p, Vector4 rc1, Vector4 rc2, Color c){
    point = p;
    firstRico = rc1;
    secondRico = rc2;
    planeColor = c;
    calcNormal();
}

void Plane::setPlaneColor(Color c) {
    planeColor = c;
}

void Plane ::calcNormal() {
    planeNormal.setX(firstRico.getY() * secondRico.getZ() - firstRico.getZ() * secondRico.getY());
    planeNormal.setY(-1*(firstRico.getX() * secondRico.getZ() - firstRico.getZ() * secondRico.getX()));
    planeNormal.setZ(firstRico.getX() * secondRico.getY() - firstRico.getY() * secondRico.getX());
}

void Plane::setPlaneNormal(Vector4 pl) {
    planeNormal = pl;
}

Vector4 Plane::getPlaneNormal() {
    return planeNormal;
}

HitPoint* Plane ::hit(RayObject *r) {
    Vector4 mid;
    mid =  point.substract(r->getOrigin());
    double teller =  planeNormal.dotProduct(mid);
    double noemer = planeNormal.dotProduct(r->getDirection());

    //cout << noemer << endl;
    if (noemer==0){
        //cout << "noemer = 0 plane" << endl;
        return nullptr;
    }
    else {
        double thit = teller / noemer;
        //cout << thit << endl;
        if (thit>0.000001) {
            //cout << thit << endl;
            Vector4* hitVector = new Vector4(r->getOrigin().getX() + thit * r->getDirection().getX(), r->getOrigin().getY() + thit * r->getDirection().getY(),
                                  r->getOrigin().getZ() + thit * r->getDirection().getZ(), 1);
            HitPoint* hitPoint = new HitPoint(*hitVector, planeColor);
            hitPoint->setHitTime(thit);
            return hitPoint;
        }
        else {
            //cout << "smaller than 0 plane" << endl;
            return nullptr;
        }
    }
}
