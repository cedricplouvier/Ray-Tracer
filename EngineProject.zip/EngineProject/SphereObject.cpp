//
// Created by Cedric Plouvier on 2019-09-27.
//

#include "SphereObject.h"

SphereObject::SphereObject(double xo, double yo, double zo, double r) {
    center = {xo, yo, zo,1};
    radius = r;
    color = {0,0,255};
}

SphereObject::~SphereObject() {}

list<HitPoint*> SphereObject::hit(RayObject *r) {
    hits.clear();
    rayz = *r;
    RayObject* transformedRay = new RayObject();
    inverseTransformationMatrix.multiplicationRay(*r,transformedRay);
    hits = objectOriginHit(transformedRay);
    transformHitpoints();
    shading();
    return hits;
}

list<HitPoint*> SphereObject :: objectOriginHit(RayObject* r) {
    list<HitPoint*> objectOriginHits;
    objectOriginHits.clear();
    //point on ray closest to center (90deg) = dot(center-rayorigin, ray direction).
    Vector4 cro = {r->getOrigin().getX(), r->getOrigin().getY(), r->getOrigin().getZ(), 0};
    //b  and a of discriminant
    double a = r->getDirection().dotProduct(r->getDirection());
    double b = 2 * dot(cro, r->getDirection());
    //c for discriminant
    double c = (cro.dotProduct(cro)) - (radius * radius);
    // calculation of discriminant
    double D = b * b - 4 * a * c;
    if (D < 0) {
        //objectOriginHits = NULL;
        return objectOriginHits;
        //return hits;
    } else {
        double hit1 = (-b - sqrtf(D)) / (2 * a);
        double hit2 = (-b + sqrtf(D)) / (2 * a);

        Vector4 hitPos1 = {(r->getOrigin().getX() + (hit1 * r->getDirection().getX())), (r->getOrigin().getY() + (hit1 * r->getDirection().getY())),
                           (r->getOrigin().getZ() + (hit1 * r->getDirection().getZ())), 1};
        Vector4 hitPos2 = {(r->getOrigin().getX() + (hit2 * r->getDirection().getX())), (r->getOrigin().getY() + (hit2 * r->getDirection().getY())),
                           (r->getOrigin().getZ() + (hit2 * r->getDirection().getZ())), 1};
        if (hit1 < hit2){

            HitPoint *hp1 = new HitPoint(hitPos1, color, hit1);
            objectOriginHits.push_front(hp1);
            return objectOriginHits;
            //hits.push_front(hp1);
        }
        else if (hit2 < hit1){
            HitPoint *hp2 = new HitPoint(hitPos2, color, hit2);
            objectOriginHits.push_front(hp2);
            return objectOriginHits;
            //hits.push_front(hp2);
        }
        return objectOriginHits;
        //return hits;
        };
}

void SphereObject::transformHitpoints() {
    for(HitPoint* hp: hits){
        hp->setHitPos(transformationMatrix.getMatrixValue(0,0)*hp->getHitPos().getX() + transformationMatrix.getMatrixValue(0,1)*hp->getHitPos().getY() + transformationMatrix.getMatrixValue(0,2)*hp->getHitPos().getZ()
                      + transformationMatrix.getMatrixValue(0,3)*hp->getHitPos().getPoint(),
                      transformationMatrix.getMatrixValue(1,0)*hp->getHitPos().getX() + transformationMatrix.getMatrixValue(1,1)*hp->getHitPos().getY() + transformationMatrix.getMatrixValue(1,2)*hp->getHitPos().getZ()
                      + transformationMatrix.getMatrixValue(1,3)*hp->getHitPos().getPoint(),
                      transformationMatrix.getMatrixValue(2,0)*hp->getHitPos().getX() + transformationMatrix.getMatrixValue(2,1)*hp->getHitPos().getY() + transformationMatrix.getMatrixValue(2,2)*hp->getHitPos().getZ()
                      + transformationMatrix.getMatrixValue(2,3)*hp->getHitPos().getPoint(),
                      transformationMatrix.getMatrixValue(3,0)*hp->getHitPos().getX() + transformationMatrix.getMatrixValue(3,1)*hp->getHitPos().getY() + transformationMatrix.getMatrixValue(3,2)*hp->getHitPos().getZ()
                      + transformationMatrix.getMatrixValue(3,3)*hp->getHitPos().getPoint());
    }
}

void SphereObject::shading(){
    for(HitPoint* hp: hits) {
        Vector4 transformedCenter = Vector4(transformationMatrix.getMatrixValue(0,0)*center.getX() + transformationMatrix.getMatrixValue(0,1)*center.getY() + transformationMatrix.getMatrixValue(0,2)*center.getZ()
                                            + transformationMatrix.getMatrixValue(0,3)*center.getPoint(),
                                            transformationMatrix.getMatrixValue(1,0)*center.getX() + transformationMatrix.getMatrixValue(1,1)*center.getY() + transformationMatrix.getMatrixValue(1,2)*center.getZ()
                                            + transformationMatrix.getMatrixValue(1,3)*center.getPoint(),
                                            transformationMatrix.getMatrixValue(2,0)*center.getX() + transformationMatrix.getMatrixValue(2,1)*center.getY() + transformationMatrix.getMatrixValue(2,2)*center.getZ()
                                            + transformationMatrix.getMatrixValue(2,3)*center.getPoint(),
                                            transformationMatrix.getMatrixValue(3,0)*center.getX() + transformationMatrix.getMatrixValue(3,1)*center.getY() + transformationMatrix.getMatrixValue(3,2)*center.getZ()
                                            + transformationMatrix.getMatrixValue(3,3)*center.getPoint());

        for(LightSource* LS : *lightsObject) {
            /*Vector4 shadowRayDirection = (LS->getLightPos().substract(hp->getHitPos())).normalizeVector();
            RayObject* shadowRay = new RayObject();
            shadowRay->setOrigin(hp->getHitPos().getX(),
                                 hp->getHitPos().getY(),hp->getHitPos().getZ(),hp->getHitPos().getPoint());
            shadowRay->setDirection(shadowRayDirection.getX(),shadowRayDirection.getY(),shadowRayDirection.getZ(),shadowRayDirection.getPoint());
            RayObject *transRay = new RayObject();
            inverseTransformationMatrix.multiplicationRay(*shadowRay, transRay);
            bool isInShadow = false;
            for(Object *o: *objectList) {
                //if(o->getName().compare(this->getName())==1) {
                //cout << this->getName() << endl;
                //o->getName();
                if(o->getName()!= "sphere3"){
                    //cout << "in calculate hit with other object" << endl;
                    list<HitPoint *> shadowHits = o->objectOriginHit(transRay);
                    if (shadowHits.size() > 0) {
                        if (shadowHits.front()->getHitTime() > 0) {
                            // << shadowHits.front()->getHitTime() << endl;
                            isInShadow = true;
                            continue;
                        }
                    }
                }
            }
            delete transRay;
            delete shadowRay;*/
            hp->setWorldNormal(hp->getHitPos().substract(transformedCenter).normalizeVector());
            Vector4 LSdir = LS->getLightPos().substract(hp->getHitPos()).normalizeVector();
            //Ambient color always present even in shadow
            hp->setHitPointColor(hp->getHitPointColorRed() + (ambientReflection[0] * LS->getAmbientRed()),
                                     hp->getHitPointColorGreen() + (ambientReflection[1] * LS->getAmbientGreen()),
                                     hp->getHitPointColorBlue() + (ambientReflection[2] * LS->getAmbientBlue()));
            //if(!isInShadow) {
                //lambert Term
                double lambertTerm = LSdir.dotProduct(hp->getWorldNormal());
                //Phong term for specular color
                Vector4 PhongDir = (LSdir.addVector(rayz.getDirection().invert())).normalizeVector();
                if (lambertTerm > 0.000000001) {
                    hp->setHitPointColor(
                            hp->getHitPointColorRed() + (lambertTerm * diffuseColor[0] * LS->getDiffuseRed()),
                            hp->getHitPointColorGreen() + (lambertTerm * diffuseColor[1] * LS->getDiffuseGreen()),
                            hp->getHitPointColorBlue() + (lambertTerm * diffuseColor[2] * LS->getDiffuseBlue()));
                    float PhongDotNormal = PhongDir.dotProduct(hp->getWorldNormal());
                    if (PhongDotNormal > 0) {
                        float phong = pow(PhongDotNormal, phongExponent);
                        hp->setHitPointColor(
                                hp->getHitPointColorRed() + (phong * specularReflection[0] * LS->getSpecularRed()),
                                hp->getHitPointColorGreen() + (phong * specularReflection[1] * LS->getSpecularGreen()),
                                hp->getHitPointColorBlue() + (phong * specularReflection[2] * LS->getSpecularBlue()));
                    }
                }
            //}
            /*else {
                hp->setHitPointColor(hp->getHitPointColorRed() + (ambientReflection[0] * LS->getAmbientRed()),
                                     hp->getHitPointColorGreen() + (ambientReflection[1] * LS->getAmbientGreen()),
                                     hp->getHitPointColorBlue() + (ambientReflection[2] * LS->getAmbientBlue()));
                //hp->setHitPointColor(0,0,1);
            }*/
        }
    }
}

bool SphereObject::shadowFeeler(RayObject* shadowRay) {
    /*for(Object *o: *objectList) {
        RayObject *transRay = new RayObject();
        inverseTransformationMatrix.multiplicationRay(*shadowRay, transRay);
        if(o->objectOriginHit(transRay).front()->getHitTime() > 0.000000000000000001){
            return true;
        }
    }
    return false;*/
    return true;
}

Vector4 SphereObject :: getCenter(){
    return center;
}

void SphereObject::setCenter(double x, double y, double z){
    center.setX(x);
    center.setY(y);
    center.setZ(z);
}

void SphereObject::setColorSphere(double r, double g, double b) {
    color.setColor(r,g,b);
}

Color SphereObject::getColorSphere(){
    return color;
}
