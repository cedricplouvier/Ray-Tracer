//
// Created by Cedric Plouvier on 2019-09-27.
//

#ifndef ENGINEPROJECT_OBJECT_H
#define ENGINEPROJECT_OBJECT_H

#include <iostream>
#include "RayObject.h"
#include "Matrix.h"
#include "HitPoint.h"
#include "LightSource.h"
#include <list>

using namespace std;

class Object {
public:
    virtual ~Object();
    Object();

    double dot(Vector4 a, Vector4 b);
    void scaleObject(double sx, double sy, double sz);
    void translateObject(double tx, double ty, double tz);
    virtual list<HitPoint*> hit(RayObject* r);
    virtual list<HitPoint*> objectOriginHit(RayObject* r);
    void setLightsObject(list<LightSource*> *LS);
    void setDiffuseObject(double dr, double dg, double db);
    void setSpecularObject(double sr, double sg, double sb);
    void setAmbientReflection(double ar, double ag, double ab);
    void setPhongExponent(double phong);
    void shadowFeeler(HitPoint* hp);

    void setObjectList(list<Object*> *ol);
    void setName(string n);
    string getName();
    list<Object*> *objectList;

protected:
    Matrix transformationMatrix;
    Matrix inverseTransformationMatrix;
    Matrix operationMatrix;
    list<LightSource*> *lightsObject;

    double diffuseColor[3];
    double specularReflection[3];
    double ambientReflection[3];
    double phongExponent;

    //list<Object*> *objectList;
    string name;
};


#endif //ENGINEPROJECT_OBJECT_H
