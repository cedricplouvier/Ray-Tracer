//
// Created by Cedric Plouvier on 2019-10-30.
//

#include "HitPoint.h"

HitPoint::~HitPoint() {}

HitPoint::HitPoint(Vector4 hp, Color c) {
    hitPos = hp;
    pointColor = c;
    hitTime = 10000;
}

HitPoint::HitPoint(Vector4 hp, Color c, double hitT) {
    hitPos = hp;
    pointColor = c;
    hitTime = hitT;
}

HitPoint::HitPoint() {
    hitPos = Vector4();
    pointColor = Color();
    hitTime = 10000;
}

double HitPoint::getHitTime() {
    return hitTime;
}

void HitPoint::setHitTime(double ht) {
    hitTime=ht;
}

Color HitPoint::getHitPointColor(){
    return pointColor;
}

void HitPoint::setHitPointColor(double r, double g, double b) {
    pointColor.setColor(r,g,b);
}

Vector4 HitPoint::getHitPos() {
    return hitPos;
}

void HitPoint::setHitPos(double x, double y, double z, double p) {
    hitPos.setX(x);
    hitPos.setY(y);
    hitPos.setZ(z);
    hitPos.setPoint(p);
}

double HitPoint::getHitPointColorRed(){
    return pointColor.getColorRed();
}

double HitPoint::getHitPointColorGreen(){
    return pointColor.getColorGreen();
}

double HitPoint::getHitPointColorBlue(){
    return pointColor.getColorBlue();
}

Vector4 HitPoint::getGenericNormal() {
    return genericNormal;
}

void HitPoint::setGenericNormal(Vector4 GN) {
    genericNormal = GN;
}

Vector4 HitPoint::getWorldNormal(){
    return worldNormal;
}

void HitPoint::setWorldNormal(Vector4 WN){
    worldNormal=WN;
}

void HitPoint::setHitPlaneNormal(Vector4 hitPlane) {
    hitPlaneNormal=hitPlane;
}

Vector4 HitPoint::getHitPlaneNormal() {
    return hitPlaneNormal;
}
