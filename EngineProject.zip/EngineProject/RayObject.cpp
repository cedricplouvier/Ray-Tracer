//
// Created by Cedric Plouvier on 2019-09-27.
//

#include "RayObject.h"

RayObject::RayObject() {
    origin = {0,0,0,1};
    direction = {0,0,0,0};
}

RayObject::RayObject(double xo, double yo, double zo, double xd, double yd, double zd) {
    origin = {xo,yo,zo,1};
    direction={xd,yd,zd,0};
}

RayObject::~RayObject() {}

void RayObject::setOrigin(double xo, double yo, double zo, double p) {
    origin.setX(xo);
    origin.setY(yo);
    origin.setZ(zo);
    origin.setPoint(p);
}
void RayObject::setDirection(double dx, double dy, double dz, double p){
    direction.setX(dx);
    direction.setY(dy);
    direction.setZ(dz);
    direction.setPoint(p);
}

Vector4 RayObject::getOrigin(){
    return origin;
}

Vector4 RayObject::getDirection() {
    return direction;
}
