//
// Created by Cedric Plouvier on 01/09/2020.
//

#include "LightSource.h"

LightSource::~LightSource() {}

LightSource::LightSource(double x, double y, double z) {
    lightPos.setX(x);
    lightPos.setY(y);
    lightPos.setZ(z);
    lightPos.setPoint(1);
}

LightSource::LightSource(double ambientR, double ambientG, double ambientB,
            double diffuseR, double diffuseG, double diffuseB,
            double specularR, double specularG, double specularB){
    ambientRed=ambientR;
    ambientGreen=ambientG;
    ambientBlue=ambientB;
    diffuseRed=diffuseR;
    diffuseGreen=diffuseG;
    diffuseBlue=diffuseB;
    specularRed=specularR;
    specularGreen=specularG;
    specularBlue=specularB;
}

Vector4 LightSource::getLightPos() {
    return lightPos;
}

void LightSource::setLightPos(double px, double py, double pz) {
    lightPos.setX(px);
    lightPos.setY(py);
    lightPos.setZ(pz);
}

void LightSource::setLightColor(double lcr, double lcg, double lcb) {
    lightColor[0]=lcr;
    lightColor[1]=lcg;
    lightColor[2]=lcb;
}

double LightSource::getAmbientRed() const {
    return ambientRed;
}

double LightSource::getAmbientGreen() const {
    return ambientGreen;
}

double LightSource::getAmbientBlue() const {
    return ambientBlue;
}

double LightSource::getDiffuseRed() const {
    return diffuseRed;
}

double LightSource::getDiffuseGreen() const {
    return diffuseGreen;
}

double LightSource::getDiffuseBlue() const {
    return diffuseBlue;
}

double LightSource::getSpecularRed() const {
    return specularRed;
}

double LightSource::getSpecularGreen() const {
    return specularGreen;
}

double LightSource::getSpecularBlue() const {
    return specularBlue;
}

void LightSource::setLightIntensities(double ambientR, double ambientG, double ambientB,
                         double diffuseR, double diffuseG, double diffuseB,
                         double specularR, double specularG, double specularB){
    ambientRed=ambientR;
    ambientGreen=ambientG;
    ambientBlue=ambientB;
    diffuseRed=diffuseR;
    diffuseGreen=diffuseG;
    diffuseBlue=diffuseB;
    specularRed=specularR;
    specularGreen=specularG;
    specularBlue=specularB;
}
