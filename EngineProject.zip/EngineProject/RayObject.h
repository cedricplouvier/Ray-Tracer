//
// Created by Cedric Plouvier on 2019-09-27.
//

#ifndef ENGINEPROJECT_RAYOBJECT_H
#define ENGINEPROJECT_RAYOBJECT_H

#include "Vector4.h"
#include <math.h>
#include <vector>
#include <cmath>

using namespace std;

class RayObject {
public:
    virtual ~RayObject();
    RayObject(double xo, double yo, double zo, double xd, double yd, double zd);
    RayObject();

    void setOrigin(double xo, double yo, double zo, double p);
    void setDirection(double dx, double dy, double dz, double p);

    Vector4 getOrigin();
    Vector4 getDirection();

private:
    Vector4 origin;
    Vector4 direction;
};


#endif //ENGINEPROJECT_RAYOBJECT_H
