#include <iostream>
#include "RayObject.h"
#include "SphereObject.h"
#include "Cube.h"
#include "HitPoint.h"

#include <glew.h>
#include <glfw3.h>
#include "gtest/gtest.h"
#include "LightSource.h"

using namespace std;

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode);
void buildScene();
void buildRay(double c, double r);

const double imageHeight=640;
const double imageWidth=640;
const double screenDistance = 1000;

list<HitPoint*> *hitpoints = new list<HitPoint*>();
list<HitPoint*> *background = new list<HitPoint*>();
list<HitPoint*> axes;
RayObject* ray = new RayObject(0,0,0,0,0,0);
Vector4 eye = {0,100,0,1};
list<Object*> *objectList = new list<Object*>();
list<LightSource*> *lights = new list<LightSource*>();

SphereObject* sphere = new SphereObject(0,0,0,1);
SphereObject* sphere2 = new SphereObject(0,0,0,1);
SphereObject* sphere3 = new SphereObject(0,0,0,1);
Cube* cube = new Cube(1);
Cube* cube2 = new Cube(1);
Cube* cube3 = new Cube(1);
Cube* cube4 = new Cube(1);
LightSource* lightSource1 = new LightSource(0,0,0);
LightSource* lightSource2 = new LightSource(0,0,0);

int main() {
    //testing::InitGoogleTest();
    //RUN_ALL_TESTS();

    buildScene();
    for(int RF=0; RF < static_cast<int>(imageHeight); RF++ ){
        cerr << "Rows remaining: " << imageHeight-RF << ' ' << endl;
        for(int CF=0; CF < static_cast<int>(imageWidth); CF++){
                double R = RF;
                double C = CF;
                buildRay(C,R);
                //HitPoint result = HitPoint({(C-((imageWidth-1)/2) )/(imageWidth/2),(R-((imageHeight-1)/2))/(imageHeight/2),0,1},{(R/(imageHeight/2)),(R/(imageHeight/2)),(R/(imageHeight/2))});
                HitPoint result;
                list<HitPoint *> newHits;
                for (Object *o : *objectList) {
                    list<HitPoint *> newHits;
                    newHits = (o->hit(ray));
                    for(HitPoint* nhp : newHits) {
                        if(nhp->getHitTime()<result.getHitTime()){
                            result = *nhp;
                        }
                    }
                }
                HitPoint* h = new HitPoint({(C-((imageWidth-1)/2) )/(imageWidth/2),(R-((imageHeight-1)/2))/(imageHeight/2),0,1},result.getHitPointColor());
                hitpoints->push_front(h);
                newHits.clear();
        }
    }



    if(!glfwInit())
        return -1;
    GLFWwindow* window = glfwCreateWindow(imageWidth,imageHeight, "Engine Project", NULL, NULL);
    if(!window)
    {
        glfwTerminate();
    }
    glfwMakeContextCurrent(window);

    glfwSetKeyCallback(window, key_callback);
    while(!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        glClearColor(0,0,0,1);
        glClear(GL_COLOR_BUFFER_BIT);
        glBegin(GL_POINTS);

        for (HitPoint* hp: *background){
            glVertex3f((hp->getHitPos().getX()), (hp->getHitPos().getY()), 0);
            glColor3f(hp->getHitPointColorRed(),hp->getHitPointColorGreen(),hp->getHitPointColorBlue());
        }
        for (HitPoint *hp : *hitpoints) {
            glColor3f(hp->getHitPointColorRed(),hp->getHitPointColorGreen(),hp->getHitPointColorBlue());
            glVertex3f((hp->getHitPos().getX()),(hp->getHitPos().getY()), 0);
        }

        glEnd();
        glfwSwapBuffers(window);
    }
    glfwTerminate();

    sphere=NULL;
    ray = NULL; //set pointer to null before deleting => dangling pointer, values still in memory (otherwise lose CPU cycles)
    cube = NULL;
    delete cube;
    delete ray;
    delete sphere;

}

void buildScene(){

    lightSource1->setLightPos(-150,100,1300);
    lightSource2->setLightPos(450,100,1500);
    lightSource1->setLightIntensities(1,1,1,1,1,1,1,1,1);
    lightSource2->setLightIntensities(1,1,1,1,1,1,1,1,1);

    lights->push_front(lightSource1);
    lights->push_front(lightSource2);

    sphere->setLightsObject(lights);
    sphere2->setLightsObject(lights);
    sphere3->setLightsObject(lights);
    cube2->setLightsObject(lights);
    cube->setLightsObject(lights);
    cube3->setLightsObject(lights);
    cube4->setLightsObject(lights);

    //Create your scene by adding all objects o your object list
    objectList->push_front(cube2);
    objectList->push_front(cube);
    objectList->push_front(sphere);
    objectList->push_front(cube3);
    objectList->push_front(cube4);
    //objectList->push_front(sphere2);
    //objectList->push_front(sphere3);

    //cube->setObjectList(objectList);
    cube2->setObjectList(objectList);
    sphere->setObjectList(objectList);
    sphere2->setObjectList(objectList);
    sphere3->setObjectList(objectList);
    cube3->setObjectList(objectList);
    cube4->setObjectList(objectList);


    //order of operations: scale, rotate, translate

    cube->setName("cube");
    cube->setCubeColor(Color(0,0,0));
    cube->setAmbientReflection(0.2,0.2,0.2);
    cube->setDiffuseObject(0.5,0.5,0.5);
    cube->setSpecularObject(0.5,0.5,0.5);
    cube->setPhongExponent(200);
    cube->scaleObject(100,100,100);
    cube->translateObject(-250,0,1500);

    cube2->setName("cube2");
    cube2->setCubeColor(Color(0,0,0));
    cube2->setAmbientReflection(0,0,0);
    cube2->setDiffuseObject(0.01,0.01,0.01);
    cube2->setSpecularObject(0.5,0.5,0.5);
    cube2->setPhongExponent(32);
    cube2->scaleObject(1000,1000,10);
    cube2->translateObject(-340,-10,2000);

    cube3->setName("cube3");
    cube3->setCubeColor(Color(0,0,0));
    //cube3->setAmbientReflection(0.2,0.2,0.2);
    //cube3->setDiffuseObject(0.01,0.01,0.01);
    //cube3->setSpecularObject(0.5,0.5,0.5);
    //cube3->setPhongExponent(32);
    cube3->scaleObject(1000,10,-2000);
    cube3->translateObject(-340,-10,2000);

    cube4->setName("cube4");
    cube4->setCubeColor(Color(0.2,0.2,0.2));
    //cube4->setAmbientReflection(0.2,0.2,0.2);
    //cube4->setDiffuseObject(0.01,0.01,0.01);
    //cube4->setSpecularObject(0.5,0.5,0.5);
    //cube4->setPhongExponent(32);
    cube4->scaleObject(10,10000,-2000);
    cube4->translateObject(-340,-10,2000);

    sphere->setName("sphere1");
    sphere->setAmbientReflection(0.2,0.2,0.2);
    sphere->setDiffuseObject(0.5,0.5,0.5);
    sphere->setSpecularObject(0.5,0.5,0.5);
    sphere->setPhongExponent(50);
    sphere->setColorSphere(0,0,0);
    sphere->scaleObject(150,150,150);
    sphere->translateObject(0,100,1500);

    sphere2->setName("sphere2");
    sphere2->setAmbientReflection(0.2,0.2,0.2);
    sphere2->setDiffuseObject(0.5,0.5,0.5);
    sphere2->setSpecularObject(0.5,0.5,0.5);
    sphere2->setPhongExponent(50);
    sphere2->setColorSphere(0,0,0);
    sphere2->scaleObject(100,100,100);
    sphere2->translateObject(-400,0,1500);

    sphere3->setName("sphere3");
    sphere3->setAmbientReflection(0.2,0.2,0.2);
    sphere3->setDiffuseObject(0.5,0.5,0.5);
    sphere3->setSpecularObject(0.5,0.5,0.5);
    sphere3->setPhongExponent(50);
    sphere3->setColorSphere(0,0,0);
    sphere3->scaleObject(100,100,100);
    sphere3->translateObject(300,0,1500);
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
    if(key==GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
    std::cout<<"ESC"<<mode;
}
void buildRay(double c, double r){

    Vector4 ndir = {0,0,1,0};
    Vector4 udir = {1,0,0,0};
    Vector4 vdir = {0,1,0,0};

    Vector4 Nndir = ndir.multiplyConstant(screenDistance);
    Vector4 Wudir = udir.multiplyConstant((imageWidth/2)*((2*c/imageWidth)-1));
    Vector4 Hvdir = vdir.multiplyConstant((imageWidth/2)*((2*r/imageHeight)-1));

    Vector4 totalV = Nndir.addVector(Wudir);
    totalV = totalV.addVector(Hvdir);
    //normalize the direction vector
    double lengthV = sqrt(totalV.dotProduct(totalV));

    Vector4 normalizedDirection = {(totalV.getX()/lengthV),(totalV.getY()/lengthV),(totalV.getZ()/lengthV),0};

    ray->setDirection(normalizedDirection.getX(),normalizedDirection.getY(),normalizedDirection.getZ(),normalizedDirection.getPoint());
    ray->setOrigin(eye.getX(),eye.getY(),eye.getZ(),eye.getPoint());
}
