//
// Created by Cedric Plouvier on 2019-10-29.
//

#ifndef ENGINEPROJECT_COLOR_H
#define ENGINEPROJECT_COLOR_H



class Color {

public:
    virtual ~Color();
    Color();
    Color(double r, double g, double b);

    void setColor(double  r, double g, double b);
    double getColorRed();
    double getColorGreen();
    double getColorBlue();
private:
    double red, green, blue;
};


#endif //ENGINEPROJECT_COLOR_H
