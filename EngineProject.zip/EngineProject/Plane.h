//
// Created by Cedric Plouvier on 2019-10-29.
//

#ifndef ENGINEPROJECT_PLANE_H
#define ENGINEPROJECT_PLANE_H

#include "Vector4.h"
#include "Color.h"
#include "RayObject.h"
#include "HitPoint.h"
#include <list>

class Plane {
public:
    virtual ~Plane();
    Plane();
    Plane(Vector4 p, Vector4 rc1, Vector4 rc2, Color c);

    void calcNormal();
    HitPoint* hit(RayObject* r);
    void setPlaneColor(Color c);
    void setPlaneNormal(Vector4 pl);
    Vector4 getPlaneNormal();

private:
    Vector4 point;
    Vector4 firstRico;
    Vector4 secondRico;
    Vector4 planeNormal;
    Color planeColor;
};


#endif //ENGINEPROJECT_PLANE_H
