//
// Created by Cedric Plouvier on 2019-10-29.
//

#include "Color.h"

Color::~Color() {}

Color::Color() {
    red=125;
    green=125;
    blue=125;
}

Color::Color(double r, double g, double b){
    red=r;
    green=g;
    blue=b;
}

void Color::setColor(double r, double g, double b){
    red = r;
    green = g;
    blue = b;
}

double Color::getColorRed(){
    return red;
}

double Color::getColorGreen(){
    return green;
}

double Color::getColorBlue(){
    return blue;
}
