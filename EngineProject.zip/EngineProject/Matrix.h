//
// Created by Cedric Plouvier on 2019-10-24.
//

#ifndef ENGINEPROJECT_MATRIX_H
#define ENGINEPROJECT_MATRIX_H

#include <iostream>
#include "RayObject.h"
#include "HitPoint.h"
#include <list>
using namespace std;
class Matrix {
public:
    Matrix();
    virtual ~Matrix();

    void resetMatrix();
    void addScaling(double sx, double sy, double sz);
    void addTranslation(double tx, double ty , double tz);
    void addIverseTranslation(double itx, double ity, double itz);
    void multiplication(Matrix m);
    void multiplicationInverse(Matrix m);
    void multiplicationRay(RayObject ray,RayObject* tr );
    void printMatrix();
    double getMatrixValue(int i, int j);
    Vector4 multiplicationVector(Vector4 v);

private:
    double matrix[4][4];
};


#endif //ENGINEPROJECT_MATRIX_H
