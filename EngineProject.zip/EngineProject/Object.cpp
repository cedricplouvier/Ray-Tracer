//
// Created by Cedric Plouvier on 2019-09-27.
//

#include "Object.h"

Object::Object() {
    transformationMatrix = Matrix();
    inverseTransformationMatrix = Matrix();
    operationMatrix = Matrix();
}

Object::~Object() {
}

double Object::dot(Vector4 a, Vector4 b) {
    double dotProd = ((a.getX()*b.getX())+(a.getY()*b.getY())+(a.getZ()*b.getZ()));
    return dotProd;
}

/*
    adds a scaling operation to the @transformationMatrix
    adds a inverse scaling operation to the @inverseTransformationMatrix
*/
void Object ::scaleObject(double sx, double sy, double sz) {
    operationMatrix.resetMatrix();
    operationMatrix.addScaling(sx,sy,sz);
    transformationMatrix.multiplicationInverse(operationMatrix);           //right.multiplication(left) = S * M
    operationMatrix.resetMatrix();
    operationMatrix.addScaling(1/sx,1/sy,1/sz);
    inverseTransformationMatrix.multiplication(operationMatrix);    //left.multiplication(right) = IM * IS
    operationMatrix.resetMatrix();
}

/*
    adds a translation operation to the @transformationMatrix
    adds a translation operation to the @inverseTransformationMatrix
*/
void Object::translateObject(double tx, double ty, double tz) {
    operationMatrix.resetMatrix();
    operationMatrix.addTranslation(tx, ty, tz);
    transformationMatrix.multiplicationInverse(operationMatrix);           //right.multiplication(left) = T * S * M
    operationMatrix.resetMatrix();
    operationMatrix.addTranslation(-tx,-ty,-tz);
    inverseTransformationMatrix.multiplication(operationMatrix);    //left.multiplication(right)
    operationMatrix.resetMatrix();
}

list<HitPoint*> Object::hit(RayObject *r) {
}

list<HitPoint*> Object::objectOriginHit(RayObject *r) {
}

void Object::setLightsObject(list<LightSource *> *LS) {
    lightsObject = LS;
}

void Object::setObjectList(list<Object *> *ol) {
    objectList = ol;
}

void Object::setDiffuseObject(double dr, double dg, double db) {
    diffuseColor[0] = dr;
    diffuseColor[1] = dg;
    diffuseColor[2] = db;
}

void Object::setSpecularObject(double sr, double sg, double sb) {
    specularReflection[0]=sr;
    specularReflection[1]=sg;
    specularReflection[2]=sb;
}

void Object ::setAmbientReflection(double ar, double ag, double ab) {
    ambientReflection[0]=ar;
    ambientReflection[1]=ag;
    ambientReflection[2]=ab;
}

void Object::setPhongExponent(double phong) {
    phongExponent=phong;
}

void Object::shadowFeeler(HitPoint* hp) {
}

void Object::setName(string n) {
    name=n;
}

string Object::getName() {
    return name;
}





