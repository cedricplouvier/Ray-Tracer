//
// Created by Cedric Plouvier on 2019-10-01.
//

#include <cmath>
#include "Vector4.h"

Vector4::~Vector4() {}

Vector4::Vector4(double xpos, double ypos, double zpos, double p) {
    x = xpos;
    y = ypos;
    z = zpos;
    point = p;      // 1 for a point and 0 for a vector
}
Vector4::Vector4(){}

void Vector4::printVector() {
    cout<<"vector: "<<x<<" "<<y<<" "<<z<< " "<<point<<endl;
}

double Vector4 ::dotProduct(Vector4 v) {
    double dot = x*v.getX() + y*v.getY() + z*v.getZ();
    return dot;
}

Vector4 Vector4 ::substract(Vector4 v) {
    Vector4 subV = {(x-v.x),(y-v.y),(z-v.z),point-v.point};
    return subV;
}
void Vector4 ::setVector(double sx, double sy, double sz, double sp) {
    x = sx;
    y=sy;
    z=sz;
    point=sp;
}

Vector4 Vector4::multiplyConstant(double c){
    Vector4 v;
    v.x=x*c;
    v.y=y*c;
    v.z=z*c;
    v.point=point;
    return v;
}

Vector4 Vector4 ::addVector(Vector4 v) {
    v.x = x + v.x;
    v.y= y + v.y;
    v.z= z + v.z;
    return v;
}

Vector4 Vector4::normalizeVector(){
    double length = sqrt((x*x) + (y*y) + (z*z) + (point*point));
    Vector4 NV;
    NV.setX(x/length);
    NV.setY(y/length);
    NV.setZ(z/length);
    NV.setPoint(point);
    return NV;
}

double Vector4::getX(){
    return x;
}

double Vector4::getY(){
    return y;
}

double Vector4::getZ(){
    return z;
}

double Vector4::getPoint() {
    return point;
}

void Vector4::setX(double sx) {
    x=sx;
}

void Vector4::setY(double sy) {
    y=sy;
}

void Vector4::setZ(double sz) {
    z=sz;
}

void Vector4::setPoint(double sp) {
    point=sp;
}

Vector4 Vector4::invert(){
    Vector4 invertedVector(-x,-y,-z,point);
    return invertedVector;
}