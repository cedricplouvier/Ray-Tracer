//
// Created by Cedric Plouvier on 2020-08-29.
//

#ifndef ENGINEPROJECT_BASICTESTS_H
#define ENGINEPROJECT_BASICTESTS_H


class basicTests {

};


#endif //ENGINEPROJECT_BASICTESTS_H
