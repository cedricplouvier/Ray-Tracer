//
// Created by Cedric Plouvier on 2020-08-29.
//

#include <gtest/gtest.h>
#include "basicTests.h"

#include "../cube.h"

TEST(EngineTests, test){
    Cube* testCube = new Cube(2);
    ASSERT_EQ(testCube->getRibSize(),2);
}