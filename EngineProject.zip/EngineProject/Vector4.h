//
// Created by Cedric Plouvier on 2019-10-01.
//

#ifndef ENGINEPROJECT_VECTOR4_H
#define ENGINEPROJECT_VECTOR4_H

#include <iostream>

using namespace std;

class Vector4 {
public:
    virtual ~Vector4();
    Vector4(double x, double y, double z, double p);
    Vector4();
    void printVector();
    double dotProduct(Vector4 v);
    Vector4 substract(Vector4 v);
    void setVector(double sx, double sy, double sz, double sp);
    Vector4 multiplyConstant(double c);
    Vector4 addVector(Vector4 v);
    Vector4 normalizeVector();

    double getX();
    double getY();
    double getZ();
    double getPoint();
    void setX(double sx);
    void setY(double sy);
    void setZ(double sz);
    void setPoint(double sp);
    Vector4 invert();
private:
    double x;
    double y;
    double z;
    double point;
};


#endif //ENGINEPROJECT_VECTOR4_H
