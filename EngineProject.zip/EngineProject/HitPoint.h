//
// Created by Cedric Plouvier on 2019-10-30.
//

#ifndef ENGINEPROJECT_HITPOINT_H
#define ENGINEPROJECT_HITPOINT_H

#include "Vector4.h"
#include "Color.h"

class HitPoint {
public:
    virtual ~HitPoint();
    HitPoint(Vector4 hp, Color c);
    HitPoint(Vector4 hp, Color c, double hitT);
    HitPoint();

    Color getHitPointColor();
    void setHitPointColor(double r, double g, double b);
    double getHitPointColorRed();
    double getHitPointColorGreen();
    double getHitPointColorBlue();
    Vector4 getHitPos();
    void setHitPos(double x, double y, double z, double p);
    double getHitTime();
    void setHitTime(double ht);
    Vector4 getGenericNormal();
    void setGenericNormal(Vector4 GN);

    Vector4 getWorldNormal();
    void setWorldNormal(Vector4 GN);
    void setHitPlaneNormal(Vector4 hitPlane);
    Vector4 getHitPlaneNormal();

private:
    Color pointColor;
    Vector4 hitPos;
    double hitTime;
    Vector4 genericNormal;
    Vector4 worldNormal;
    Vector4 hitPlaneNormal;
};


#endif //ENGINEPROJECT_HITPOINT_H
