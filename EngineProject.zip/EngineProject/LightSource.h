//
// Created by Cedric Plouvier on 01/09/2020.
//

#ifndef ENGINEPROJECT_LIGHTSOURCE_H
#define ENGINEPROJECT_LIGHTSOURCE_H

#include "Vector4.h"

class LightSource {
public:
    virtual ~LightSource();
    LightSource(double x, double y, double z);
    LightSource(double ambientRed, double ambienGreen, double ambientBlue,
                double diffuseRed, double diffuseGreen, double diffuseBlue,
                double specularRed, double specularGreen, double specularBlue);

    LightSource(double *lightColor);

    Vector4 getLightPos();
    void setLightColor(double lcr, double lcg, double lcb);
    void setLightPos(double px, double py, double pz);
    double getLightColor();
    double lightColor[3];
    void setLightIntensities(double ambientRed, double ambienGreen, double ambientBlue,
                             double diffuseRed, double diffuseGreen, double diffuseBlue,
                             double specularRed, double specularGreen, double specularBlue);
private:
    Vector4 lightPos;
    double ambientRed, ambientGreen, ambientBlue, diffuseRed, diffuseGreen, diffuseBlue, specularRed, specularGreen, specularBlue;
public:
    double getSpecularBlue() const;

public:
    double getSpecularGreen() const;

public:
    double getSpecularRed() const;

public:
    double getDiffuseBlue() const;

public:
    double getDiffuseGreen() const;

public:
    double getDiffuseRed() const;

public:
    double getAmbientBlue() const;

public:
    double getAmbientGreen() const;

public:
    double getAmbientRed() const;
};


#endif //ENGINEPROJECT_LIGHTSOURCE_H
