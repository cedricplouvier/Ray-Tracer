//
// Created by Cedric Plouvier on 2019-10-29.
//

#include "Cube.h"


Cube::~Cube() {
}
Cube::Cube(double size) {
    ribSize = 1;

    cubePoints.push_front(new Vector4(0,0,0,1));
    cubePoints.push_front(new Vector4(size,0,0,1));
    cubePoints.push_front(new Vector4(0,size,0,1));
    cubePoints.push_front(new Vector4(0,0,size,1));
    cubePoints.push_front(new Vector4(size,size,0,1));
    cubePoints.push_front(new Vector4(size,0,size,1));
    cubePoints.push_front(new Vector4(0,size,size,1));
    cubePoints.push_front(new Vector4(size,size,size,1));

    //XY-plane: red
    Plane *XY = new Plane(Vector4(0,0,0,1),Vector4(1,0,0,0),Vector4(0,1,0,0),Color(255,0,0));
    XY->setPlaneNormal(Vector4(0,0,-1,0));
    cubePlanes.push_front(XY);
    //cubePlanes.push_front(new Plane(Vector4(0,0,0,1),Vector4(1,0,0,0),Vector4(0,1,0,0),Color(255,0,0)));
    //XZ-plane: green
    Plane *XZ = new Plane(Vector4(0,0,0,1),Vector4(1,0,0,0),Vector4(0,0,1,0),Color(0,255,0));
    XZ->setPlaneNormal(Vector4(0,-1,0,0));
    cubePlanes.push_front(XZ);
    //cubePlanes.push_front(new Plane(Vector4(0,0,0,1),Vector4(1,0,0,0),Vector4(0,0,1,0),Color(0,255,0)));
    //YZ-plane: blue
    Plane *YZ = new Plane(Vector4(0,0,0,1),Vector4(0,1,0,0),Vector4(0,0,1,0),Color(0,0,255));
    YZ->setPlaneNormal(Vector4(-1,0,0,0));
    cubePlanes.push_front(YZ);
    //cubePlanes.push_front(new Plane(Vector4(0,0,0,1),Vector4(0,1,0,0),Vector4(0,0,1,0),Color(0,0,255)));
    //XY+ZZ planes: yellow
    Plane *XYZ = new Plane(Vector4(0,0,size,1),Vector4(1,0,0,0),Vector4(0,1,0,0),Color(255,255,0));
    XYZ->setPlaneNormal(Vector4(0,0,1,0));
    cubePlanes.push_front(XYZ);
    //cubePlanes.push_front(new Plane(Vector4(0,0,size,1),Vector4(1,0,0,0),Vector4(0,1,0,0),Color(255,255,0)));
    //XZ-plane+Y: cyan
    Plane *XZY = new Plane(Vector4(0,size,0,1),Vector4(1,0,0,0),Vector4(0,0,1,0),Color(0,0,0));
    XZY->setPlaneNormal(Vector4(0,1,0,0));
    cubePlanes.push_front(XZY);
    //cubePlanes.push_front(new Plane(Vector4(0,size,0,1),Vector4(1,0,0,0),Vector4(0,0,1,0),Color(0,0,0)));
    //YZ+X plane: magenta
    Plane *YZX = new Plane(Vector4(size,0,0,1),Vector4(0,1,0,0),Vector4(0,0,1,0),Color(255,0,255));
    YZX->setPlaneNormal(Vector4(1,0,0,0));
    cubePlanes.push_front(YZX);
    //cubePlanes.push_front(new Plane(Vector4(size,0,0,1),Vector4(0,1,0,0),Vector4(0,0,1,0),Color(255,0,255)));
}

list<HitPoint*> Cube::hit(RayObject *r) {

    hits.clear();
    rayz = *r;
    RayObject* transformedRay = new RayObject();
    inverseTransformationMatrix.multiplicationRay(*r,transformedRay);
    hits = objectOriginHit(transformedRay);
    transformHitpoints();
    shading();
    return hits;
}

list<HitPoint*> Cube :: objectOriginHit(RayObject* transformedRay){
    list<HitPoint*> objectOriginHits;
    double eps = 0.00000001;
    double t =1000000;
    HitPoint* result;
    for(Plane* plane : cubePlanes){
        HitPoint* point = plane->hit(transformedRay);

        if (point != nullptr){
            if ((point->getHitPos().getX() >= 0.0-eps && point->getHitPos().getX()  <= 1.0+eps)&&(point->getHitPos().getY() >= 0.0-eps && point->getHitPos().getY()  <= 1.0+eps)&&(point->getHitPos().getZ() >= 0.0-eps && point->getHitPos().getZ()  <= 1.0+eps)){
                if(point->getHitTime()<t){
                    t=point->getHitTime();
                    result = point;
                }
                result->setHitPlaneNormal(plane->getPlaneNormal());
                objectOriginHits.push_front(result);
                hits.push_front(result);
            }
            else{
                //cout << "no hit" << endl;
            }
        }
    }
    return objectOriginHits;
    //return hits;
}

void Cube::transformHitpoints() {
    for(HitPoint* hp: hits){
        hp->setHitPos(transformationMatrix.getMatrixValue(0,0)*hp->getHitPos().getX() + transformationMatrix.getMatrixValue(0,1)*hp->getHitPos().getY() + transformationMatrix.getMatrixValue(0,2)*hp->getHitPos().getZ()
                      + transformationMatrix.getMatrixValue(0,3)*hp->getHitPos().getPoint(),
                      transformationMatrix.getMatrixValue(1,0)*hp->getHitPos().getX() + transformationMatrix.getMatrixValue(1,1)*hp->getHitPos().getY() + transformationMatrix.getMatrixValue(1,2)*hp->getHitPos().getZ()
                      + transformationMatrix.getMatrixValue(1,3)*hp->getHitPos().getPoint(),
                      transformationMatrix.getMatrixValue(2,0)*hp->getHitPos().getX() + transformationMatrix.getMatrixValue(2,1)*hp->getHitPos().getY() + transformationMatrix.getMatrixValue(2,2)*hp->getHitPos().getZ()
                      + transformationMatrix.getMatrixValue(2,3)*hp->getHitPos().getPoint(),
                      transformationMatrix.getMatrixValue(3,0)*hp->getHitPos().getX() + transformationMatrix.getMatrixValue(3,1)*hp->getHitPos().getY() + transformationMatrix.getMatrixValue(3,2)*hp->getHitPos().getZ()
                      + transformationMatrix.getMatrixValue(3,3)*hp->getHitPos().getPoint());
    }
}

void Cube::shading() {
    for(HitPoint* hp: hits) {

        hp->setGenericNormal(hp->getHitPlaneNormal().normalizeVector()); //this line does not make any difference since it's already the generic normal
        //Vector4 genericNormal = hp->getGenericNormal();
        //hp->setWorldNormal(Vector4(1,1,1,1));
        hp->setWorldNormal(Vector4(transformationMatrix.getMatrixValue(0,0)*hp->getHitPlaneNormal().getX() + transformationMatrix.getMatrixValue(0,1)*hp->getHitPlaneNormal().getY() + transformationMatrix.getMatrixValue(0,2)*hp->getHitPlaneNormal().getZ()
                           + transformationMatrix.getMatrixValue(0,3)*hp->getHitPlaneNormal().getPoint(),
                           transformationMatrix.getMatrixValue(1,0)*hp->getHitPlaneNormal().getX() + transformationMatrix.getMatrixValue(1,1)*hp->getHitPlaneNormal().getY() + transformationMatrix.getMatrixValue(1,2)*hp->getHitPlaneNormal().getZ()
                           + transformationMatrix.getMatrixValue(1,3)*hp->getHitPlaneNormal().getPoint(),
                           transformationMatrix.getMatrixValue(2,0)*hp->getHitPlaneNormal().getX() + transformationMatrix.getMatrixValue(2,1)*hp->getHitPlaneNormal().getY() + transformationMatrix.getMatrixValue(2,2)*hp->getHitPlaneNormal().getZ()
                           + transformationMatrix.getMatrixValue(2,3)*hp->getHitPlaneNormal().getPoint(),
                           transformationMatrix.getMatrixValue(3,0)*hp->getHitPlaneNormal().getX() + transformationMatrix.getMatrixValue(3,1)*hp->getHitPlaneNormal().getY() + transformationMatrix.getMatrixValue(3,2)*hp->getHitPlaneNormal().getZ()
                           + transformationMatrix.getMatrixValue(3,3)*hp->getHitPlaneNormal().getPoint()).normalizeVector());
        for(LightSource* LS : *lightsObject) {

            Vector4 LSdir = LS->getLightPos().substract(hp->getHitPos());
            LSdir = LSdir.normalizeVector();
            //Ambient color always present even in shadow
            hp->setHitPointColor(hp->getHitPointColorRed() + (ambientReflection[0] * LS->getAmbientRed()),
                                 hp->getHitPointColorGreen() + (ambientReflection[1] * LS->getAmbientGreen()),
                                 hp->getHitPointColorBlue() + (ambientReflection[2] * LS->getAmbientBlue()));
            //lambert Term
            double lambertTerm = LSdir.dotProduct(hp->getWorldNormal());
            //Phong term for specular color
            Vector4 PhongDir = (LSdir.addVector(rayz.getDirection().invert())).normalizeVector();
            if (lambertTerm > 0.000000001) {
                hp->setHitPointColor(hp->getHitPointColorRed() + (lambertTerm * diffuseColor[0] * LS->getDiffuseRed()),
                                     hp->getHitPointColorGreen() + (lambertTerm * diffuseColor[1] * LS->getDiffuseGreen()),
                                     hp->getHitPointColorBlue() + (lambertTerm * diffuseColor[2] * LS->getDiffuseBlue()));
                float PhongDotNormal = PhongDir.dotProduct(hp->getWorldNormal());
                if(PhongDotNormal > 0){
                    float phong = pow(PhongDotNormal,phongExponent);
                    hp->setHitPointColor(hp->getHitPointColorRed() + (phong * specularReflection[0] * LS->getSpecularRed()),
                                         hp->getHitPointColorGreen() + (phong * specularReflection[1] * LS->getSpecularGreen()),
                                         hp->getHitPointColorBlue() + (phong * specularReflection[2] * LS->getSpecularBlue()));
                }
            }
            else {
                //in shadow but colors matter for reflection
                hp->setHitPointColor(hp->getHitPointColorRed(), hp->getHitPointColorGreen(),
                                     hp->getHitPointColorBlue());
            }
        }
    }
}

void Cube::changePlaneColor(Color c, int planeNumber){
    list<Plane*>::iterator it = cubePlanes.begin();
    advance(it,planeNumber);
    Plane* pl = *it;
    pl->setPlaneColor(c);
}

void Cube::setCubeColor(Color c){
    for(int i=0; i < cubePlanes.size(); i++){
        changePlaneColor(c,i);
    }
}

void Cube::setRibSize(double rs) {
    ribSize=rs;
}

double Cube::getRibSize() {
    return ribSize;
}



