//
// Created by Cedric Plouvier on 2019-10-24.
//

#include "Matrix.h"

Matrix::Matrix() {
    // fill matrix diagonals with 1
    for (int i = 0;i<4;i++){
        for (int j=0;j<4;j++){
            if (i==j){
                matrix[i][j]=1;
            }
            else {
                matrix[i][j]=0;
            }
        }
    }
}

Matrix::~Matrix() {}

void Matrix::resetMatrix() {
    for (int i = 0;i<4;i++){
        for (int j=0;j<4;j++){
            if (i==j){
                matrix[i][j]=1;
            }
            else {
                matrix[i][j]=0;
            }
        }
    }
}

/* scaling Matrix

    sx  0   0   0
    0   sy  0   0
    0   0   sz  0
    0   0   0   1
 */
void Matrix::addScaling(double sx, double sy, double sz) {
    matrix[0][0] = sx;
    matrix[1][1] = sy;
    matrix[2][2] = sz;
}

/* translation Matrix

        1   0   0   tx
        0   1   0   ty
        0   0   1   tz
        0   0   0   1
*/
void Matrix::addTranslation(double tx, double ty, double tz) {
    matrix[0][3] = tx;
    matrix[1][3] = ty;
    matrix[2][3] = tz;
}

void Matrix::multiplication(Matrix m) {
    double mult[4][4] = {};

    for (int row = 0;row <4;row++){
        for (int column = 0;column < 4;column++){
            for (int val = 0;val<4;val++){
                mult[row][column] += matrix[row][val] * m.matrix[val][column];
            }
        }
    }

    for (int i=0;i<4;i++){
        for (int j = 0;j<4;j++)
            matrix[i][j] = mult[i][j];
    }
}

void Matrix::multiplicationInverse(Matrix m) {
    double mult[4][4] = {};

    for (int row = 0;row <4;row++){
        for (int column = 0;column < 4;column++){
            for (int val = 0;val<4;val++){
                mult[row][column] += m.matrix[row][val] * matrix[val][column];
            }
        }
    }

    for (int i=0;i<4;i++){
        for (int j = 0;j<4;j++)
            matrix[i][j] = mult[i][j];
    }
}

void Matrix::multiplicationRay(RayObject ray,RayObject* tr ){

    tr->setOrigin(matrix[0][0]*ray.getOrigin().getX() + matrix[0][1]*ray.getOrigin().getY() + matrix[0][2]*ray.getOrigin().getZ() + matrix[0][3]*ray.getOrigin().getPoint(),
                      matrix[1][0]*ray.getOrigin().getX() + matrix[1][1]*ray.getOrigin().getY() + matrix[1][2]*ray.getOrigin().getZ() + matrix[1][3]*ray.getOrigin().getPoint(),
                      matrix[2][0]*ray.getOrigin().getX() + matrix[2][1]*ray.getOrigin().getY() + matrix[2][2]*ray.getOrigin().getZ() + matrix[2][3]*ray.getOrigin().getPoint(),
                      matrix[3][0]*ray.getOrigin().getX() + matrix[3][1]*ray.getOrigin().getY() + matrix[3][2]*ray.getOrigin().getZ() + matrix[3][3]*ray.getOrigin().getPoint());

    tr->setDirection(matrix[0][0]*ray.getDirection().getX() + matrix[0][1]*ray.getDirection().getY() + matrix[0][2]*ray.getDirection().getZ() + matrix[0][3]*ray.getDirection().getPoint(),
                      matrix[1][0]*ray.getDirection().getX() + matrix[1][1]*ray.getDirection().getY() + matrix[1][2]*ray.getDirection().getZ() + matrix[1][3]*ray.getDirection().getPoint(),
                      matrix[2][0]*ray.getDirection().getX() + matrix[2][1]*ray.getDirection().getY() + matrix[2][2]*ray.getDirection().getZ() + matrix[2][3]*ray.getDirection().getPoint(),
                      matrix[3][0]*ray.getDirection().getX() + matrix[3][1]*ray.getDirection().getY() + matrix[3][2]*ray.getDirection().getZ() + matrix[3][3]*ray.getDirection().getPoint());
}

Vector4 Matrix::multiplicationVector(Vector4 norm){
    Vector4 MV;
    MV.setX(matrix[0][0]*norm.getX() + matrix[0][1]*norm.getY() + matrix[0][2]*norm.getZ() + matrix[0][3]*norm.getPoint());
    MV.setY(matrix[1][0]*norm.getX() + matrix[1][1]*norm.getY() + matrix[1][2]*norm.getZ() + matrix[1][3]*norm.getPoint());
    MV.setZ(matrix[2][0]*norm.getX() + matrix[2][1]*norm.getY() + matrix[2][2]*norm.getZ() + matrix[2][3]*norm.getPoint());
    MV.setPoint(matrix[3][0]*norm.getX() + matrix[3][1]*norm.getY() + matrix[3][2]*norm.getZ() + matrix[3][3]*norm.getPoint());
    return MV;
}

void Matrix ::printMatrix() {

    for(int i=0; i<4 ; i++ ){
        cout << endl;
        for(int j=0; j<4 ; j++){
            cout << matrix[i][j] << " ";
        }
    }
    cout << endl;
}

double ::Matrix::getMatrixValue(int i, int j){
    return matrix[i][j];
}
